
#ifndef __RTCUTILITY_H__
#define __RTCUTILITY_H__

extern uint8_t BcdToUint8(uint8_t val);
extern uint8_t Uint8ToBcd(uint8_t val);
extern uint8_t BcdToBin24Hour(uint8_t bcdHour);

#endif // __RTCUTILITY_H__
